class switch1 {
String switchb(String f){
	return switch(f){
	'apple' || 'APPLE'=>f,
	'pineapple' || 'pineapple'=>f,
	'guava' || 'GUAVA'=>f,
	_=>"not list",
		};
}
}