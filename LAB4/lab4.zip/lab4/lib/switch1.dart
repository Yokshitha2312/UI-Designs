class switch1 {
void switchb(String f){
	var x= switch(f){
	'apple' || 'APPLE'=>f,
	'pineapple' || 'pineapple'=>f,
	'guava' || 'GUAVA'=>f,
	_=>"not list",
		};
print(x);
}
}