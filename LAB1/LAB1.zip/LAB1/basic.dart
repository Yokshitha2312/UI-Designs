import 'dart:io';
void main()
{
print("UI Design");
print("Flutter");
stdout.write("Lab");
String name = stdin.readLineSync()!;
}